#include<stdio.h>
int main(){
    unsigned long long num;
    printf("Size of num is \\%d bytes\\\n",sizeof(num));
}