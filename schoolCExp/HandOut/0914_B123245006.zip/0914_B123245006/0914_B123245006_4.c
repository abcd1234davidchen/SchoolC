#include<stdio.h>
int main(void){
    char ch;
    printf("輸入一字元");
    scanf("%c",&ch);
    printf("剛剛輸入了%c字元",ch);
    return 0;
}
