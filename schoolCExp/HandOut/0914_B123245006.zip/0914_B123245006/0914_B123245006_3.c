#include<stdio.h>
int main(void){
    int a = 10, b = 8, num;
    printf("a = %d\n",a);
    printf("b = %d\n",b);
    num = a+b;
    printf("兩數之和 = %d\n",num);
    num = a*b;
    printf("兩數之積 = %d\n",num);
    return 0;
}
