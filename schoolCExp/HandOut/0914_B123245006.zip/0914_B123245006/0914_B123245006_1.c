#include<stdio.h>
int main(void){
    int a = 18;
    float b = 3.14;
    char ch = 'A';
    printf("年齡：  %d\n",a);
    printf("圓周率：  %f\n",b);
    printf("第一個英文字母：  %c\n",ch);
    return 0;
}
