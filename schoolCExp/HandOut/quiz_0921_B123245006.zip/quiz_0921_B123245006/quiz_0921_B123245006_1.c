#include<stdio.h>
int main(void){
    printf("I'm super shy, super shy\n");
    printf("But wait a minute while I make you mine make you mine~\n");
    printf("Y(^_^)Y\n");
    return 0;
}
