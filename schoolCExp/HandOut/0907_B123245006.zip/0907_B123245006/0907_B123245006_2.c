#include<stdio.h>

int main(void){
//  printf("    科系：資訊工程系\n");
/*  printf("    學號：B123245006\n");
    printf("    姓名：陳展皝\n");
    printf("    好累\n");*/
    printf("註解已完成");
    return 0;
}
